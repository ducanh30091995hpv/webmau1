<?php

/**
 * NukeViet Content Management System
 * @version 4.x
 * @author VINADES.,JSC <contact@vinades.vn>
 * @copyright (C) 2009-2021 VINADES.,JSC. All rights reserved
 * @license GNU/GPL version 2 or any later version
 * @see https://github.com/nukeviet The NukeViet CMS GitHub project
 */

$lang_block['qr_level'] = 'Qualité des images';
$lang_block['qr_pixel_per_point'] = 'Taille de QR-code ';
$lang_block['qr_outer_frame'] = 'Bord de QR-code';
$lang_block['cominfo_map_yes'] = 'Activez Google MAP';
$lang_block['cominfo_map_no'] = 'Désactivew Google MAP';
$lang_block['cominfo_mapurl'] = 'Google MAP Iframe URL';
